<?php
    include 'db_conncet.php';~

    $nome=$POST['nome'];
    $data-nascimento_str=$_POST['nascimento'];
    $municipio_atleta=$_POST['municipio'];
    $clube_id=NULL;
    $nivel_equipa= "";
function calc($data-nascimento_str){
    $hoje= new DateTime();
    $nascimento = new DateTime($data_nascimento_str);
    $idade = $nascimento->diff($hoje)->y;

    if($idade>=19){
        return "Sênior";
    }elseif ($idade>=16){
       return"Sênior";
    }elseif ($idade>=12){
       return"Júnior";
    }elseif ($idade>=7){
       return"Infantil";
    }

}
?>