<?php
$hostname="localhost";
$db="db_fifa";
$usuario= "root";
$senhas= "";

$conn = new mysqli($hostname, $usuario,$senhas , $db);

if($conn->connect_error){
    die("Erro na conexão: " . $conn->connect_error);
}
?>